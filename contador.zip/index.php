<?php

require_once 'geoplugin.class.php';

setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
date_default_timezone_set('America/Sao_Paulo');

define("FILENAME", 'dados.txt');

if (!file_exists(FILENAME)) touch(FILENAME);

function getOS($user_agent) {

    $os_array       =   array(
        '/Windows nt 10.0/i'    => 'Windows 10',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/windows nt 6.0/i'     =>  'Windows Vista',
        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     =>  'Windows XP',
        '/windows xp/i'         =>  'Windows XP',
        '/windows nt 5.0/i'     =>  'Windows 2000',
        '/windows me/i'         =>  'Windows ME',
        '/win98/i'              =>  'Windows 98',
        '/win95/i'              =>  'Windows 95',
        '/win16/i'              =>  'Windows 3.11',
        '/macintosh|mac os x/i' =>  'Mac OS X',
        '/mac_powerpc/i'        =>  'Mac OS 9',
        '/linux/i'              =>  'Linux',
        '/ubuntu/i'             =>  'Ubuntu',
        '/iphone/i'             =>  'iPhone',
        '/ipod/i'               =>  'iPod',
        '/ipad/i'               =>  'iPad',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );

    foreach ($os_array as $regex => $value) {

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "NAVEGADOR DESCONHECIDO";

    $browser_array  =   array(
        '/msie/i'       =>  'Internet Explorer',
        '/firefox/i'    =>  'Firefox',
        '/safari/i'     =>  'Safari',
        '/chrome/i'     =>  'Chrome',
        '/opera/i'      =>  'Opera',
        '/netscape/i'   =>  'Netscape',
        '/maxthon/i'    =>  'Maxthon',
        '/konqueror/i'  =>  'Konqueror',
        '/mobile/i'     =>  'Handheld Browser'
    );

    foreach ($browser_array as $regex => $value) {

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }
        if (preg_match('|MSIE ([0-9].[0-9]{1,2})|',$user_agent,$matched)) {
            $browser_version=$matched[1];
            $browser = 'Internet Explorer';
        } elseif (preg_match( '|Opera/([0-9].[0-9]{1,2})|',$user_agent,$matched)) {
            $browser_version=$matched[1];
            $browser = 'Opera';
        } elseif(preg_match('|Firefox/([0-9\.]+)|',$user_agent,$matched)) {
            $browser_version=$matched[1];
            $browser = 'Mozila Firefox';
        } elseif(preg_match('|Chrome/([0-9\.]+)|',$user_agent,$matched)) {
            $browser_version=$matched[1];
            $browser = 'Google Chrome';
        } elseif(preg_match('|Safari/([0-9\.]+)|',$user_agent,$matched)) {
            $browser_version=$matched[1];
            $browser = 'Safari';
        } else {
            // browser not recognized!
            $browser_version = 0;
            //$browser= 'other';
        }

    }
    return $browser;
}

$list = [];
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$hour = date("H:i:s");

$geoplugin = new geoPlugin();
$geoplugin->locate($ip);

$dateToday = utf8_encode(ucfirst(strftime('%A, %d de %B de %Y', strtotime('today'))));
$full = $dateToday . " as " . $hour . " - ". $ip. " - ". getOS($user_agent) . " - ". getBrowser() . " - ". $geoplugin->city . " - ". $geoplugin->region. " - ". $geoplugin->countryName;

$handle = fopen(FILENAME, 'r');
$signup = explode(" - ", $full)[1];

while (!feof($handle)){
    $line = fgets($handle, 4096);
    $unique = explode(" - ", $line);
    if (isset($unique[1])) {
        if (in_array($signup, $unique)) die("<p style='text-align: center;margin: 0 auto'>IP: $ip já Cadastrado!</p>");
    }
}

fclose($handle);

if (!empty($geoplugin->city) || !empty($geoplugin->region) || !empty($geoplugin->countryName)) {
    if ($geoplugin->countryName == 'Brazil') {
        $handle = fopen(FILENAME, "a+");
        fwrite($handle, $full."\r\n");
        fclose($handle);
    }
}
