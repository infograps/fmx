<?php

$lines = file_get_contents("dados.txt");
$lines = explode("\n", $lines);
$lines = array_unique($lines);
$num_linhas = count($lines) -1;
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="50;URL=clientes.php" />
<title>Total.: ( <?=$num_linhas;?> )</title>
<body style="background-color: #475163; color: #FFF; margin: 0">
<p style="margin-top: 30px; text-align: center; font-size: 16pt; color: #d94452; font-family: Verdana, Arial, Helvetica, sans-serif;"><strong>Acessos: ( <?=$num_linhas;?> )</strong></p>
<p style="padding-left: 5px; font-size: 10pt; font-family: Verdana, Arial, Helvetica, sans-serif">
<?php
$num_linhas = 0;
foreach ($lines as $linha) {
      if ($linha != ""){
          $num_linhas++;
          echo $num_linhas." - ".$linha."<font color='#35ba9b' size='2' face='Verdana, Arial, Helvetica, sans-serif'> [Mais um cliente cadastrado...]</font></strong><br>";
      }
}
